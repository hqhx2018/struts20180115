# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html
from items import YunqiBookListItem
from items import YunqiBookDetailItem
import pymongo
import re

class YunqiPipeline(object):
	
	#定义构造方法
	def __init__(self,dbUrl,dbName,repset):
		print "----------------------YunqiPipeline构造----------------------------"
		self.dbUrl=dbUrl
		self.dbName=dbName
		self.repset=repset
		print self.dbUrl,self.dbName

	#当Spider被开启时调用
	def open_spider(self,spider):
		#self.client=pymongo.MongoClient(self.dbUrl,replicaset=self.repset,wtimeoutMS=200000000)
		self.client=pymongo.MongoClient("mongodb://192.168.32.1:27021")
		print self.client
		self.db=self.client['ppp']

	#当Spider被关闭时调用
	def close_spider(self,spider):
		self.client.close()

	#类方法，读取settings配置文件的信息
	@classmethod
	def from_crawler(cls,crawler):
		print "----------------------静态方法------------------------------"
		dbUrl=crawler.settings.get("MONGODB_URL")
		dbName=crawler.settings.get("MONGODB_NAME","yunqi")
		repset=crawler.settings.get("REPLICASET")
		return cls(dbUrl,dbName,repset)
		
		



	def process_item(self, item, spider):
		#判断item是否为
		#1.存储列表信息
		if isinstance(item,YunqiBookListItem):
			self.saveListItem(item)
		#2.存储详细信息
       		else:
			self.saveDetailItem(item) 
		return item

	#存储列表信息
	def  saveListItem(self,item):
		print self.db
		#连接数据库获取一个Client，创建数据库，创建集合，插入数据
		self.db.bookItem.insert(dict(item))

	def saveDetailItem(self,item):
		#把item的数据进行清洗
		pattern=re.compile("\d+")
		match=pattern.search(item['novelAllClick'])
		item['novelAllClick']=match.group() if match else item['novelAllClick']
		match=pattern.search(item['novelMonthClick'])
		item['novelMonthClick']=match.group() if match else item['novelMonthClick']
		match=pattern.search(item['novelWeekClick'])
		item['novelWeekClick']=match.group() if match else item['novelWeekClick']
		match=pattern.search(item['novelAllPopular'])
		item['novelAllPopular']=match.group() if match else item['novelAllPopular']
		match=pattern.search(item['novelMonthPopular'])
		item['novelMonthPopular']=match.group() if match else item['novelMonthPopular']
		match=pattern.search(item['novelWeekPopular'])
		item['novelWeekPopular']=match.group() if match else item['novelWeekPopular']
		match=pattern.search(item['novelAllComm'])
		item['novelAllComm']=match.group() if match else item['novelAllComm']
		match=pattern.search(item['novelMonthComm'])
		item['novelMonthComm']=match.group() if match else item['novelMonthComm']
		match=pattern.search(item['novelWeekComm'])
		item['novelWeekComm']=match.group() if match else item['novelWeekComm']
		match=pattern.search(item['novelCommentNum'])
		item['novelCommentNum']=match.group() if match else item['novelCommentNum']
		#连接数据库获取一个Client，创建数据库，创建集合，插入数据
		self.db.bookItem.insert(dict(item))
