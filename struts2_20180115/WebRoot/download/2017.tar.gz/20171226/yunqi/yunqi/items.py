# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class YunqiBookListItem(scrapy.Item):
	#1.小说的编号
	novelId=scrapy.Field()
	#2.小说的名字
	novelName=scrapy.Field()
	#3.小说的作者
	novelAuthor=scrapy.Field()
	#4.小说的分类
	novelType=scrapy.Field()
	#5.小说的状态
	novelStatus=scrapy.Field()
	#6.小说的更新时间
	novelUpdateTime=scrapy.Field()
	#7.小说的字数
	novelWords=scrapy.Field()
	#8.详细信息的url
	novelDetailUrl=scrapy.Field()
	#9.小说的封面的url
	novelImageUrl=scrapy.Field()

class YunqiBookDetailItem(scrapy.Item):
	#1.小说的编号
	novelId=scrapy.Field()
	#2.小说的作品标签
	novelLable=scrapy.Field()
	#3.小说的总点击量
	novelAllClick=scrapy.Field()
	#4.小说的月点击量
	novelMonthClick=scrapy.Field()
	#5.小说的周点击量
	novelWeekClick=scrapy.Field()
	#6.小说的总人气
	novelAllPopular=scrapy.Field()
	#7.小说的月人气
	novelMonthPopular=scrapy.Field()
	#8.小说的周人气
	novelWeekPopular=scrapy.Field()
	#9.小说的总推荐
	novelAllComm=scrapy.Field()
	#10.小说的月推荐
	novelMonthComm=scrapy.Field()
	#11.小说的周推荐
	novelWeekComm=scrapy.Field()
	#12.总评论数
	novelCommentNum=scrapy.Field()
