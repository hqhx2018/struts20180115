import scrapy

class zhihuSpider(scrapy.Spider):
	name="zhihu"
	start_urls=["https://www.zhihu.com"]

	
	def parse(self,response):
			print "-------------------------------------"
			print response
