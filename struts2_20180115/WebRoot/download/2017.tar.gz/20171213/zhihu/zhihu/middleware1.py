#coding:utf-8
import random

class Middleware1(object):
	#m=Middleware1()
	#cls()
	def __init__(self,agents,a):
		print "---------------------构造方法-------------------------"
		self.agents=agents
		self.a=a
		print self.agents
		print self.a
	

	@classmethod
	def from_crawler(cls, crawler):
		print "------------------------------------------------静态方法------------------------------------"
		print crawler.settings.getlist('USER_AGENTS')
		# 获取settings的USER_AGENT列表并返回
		return cls(crawler.settings.getlist('USER_AGENTS'),12)


	def process_request(self,request,spider):
		print '--------------------------process_request----------------------------------------'
		request.headers.setdefault('User_Agent',"Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_8; en-us) AppleWebKit/534.50 (KHTML, like Gecko) Version/5.1 Safari/534.50")
		print request.headers.get("User_Agent")
		request.meta['proxy']="http://222.182.53.253:8118"
		return None

	def process_response(self,request,response,spider):
		print '--------------------------process_response----------------------------------------'
		return response

	def process_exception(self,request,exception,spider):
		print '--------------------------process_exception----------------------------------------'
		return None


