import scrapy

class XMLSpider(scrapy.Spider):
	name='login'
	start_urls=['http://192.168.32.1:8020/loginInput']
	
	def parse(self,response):
		return scrapy.FormRequest.from_response(response,formdata={'username':'zhangsan','password':'123456'}, callback=self.after_login)

	def after_login(self,response):
		for url in response.xpath('//div/a/text()').extract():
			print url
		
