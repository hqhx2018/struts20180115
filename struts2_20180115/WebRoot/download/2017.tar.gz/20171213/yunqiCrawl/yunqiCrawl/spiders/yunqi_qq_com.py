# -*- coding: utf-8 -*-
import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule
from yunqiCrawl.items import YunqiBookListItem
from yunqiCrawl.items import YunqiBookDetailItem


class YunqiQqComSpider(CrawlSpider):
	name = 'yunqi.qq.com'
	allowed_domains = ['yunqi.qq.com']
	start_urls = ['http://yunqi.qq.com/bk/so2/n10p1']

	rules = (
        Rule(LinkExtractor(allow=r'http://yunqi.qq.com/bk/so2/n10p\d+'), callback='yunqiListSpider', follow=True),
    )

	#解析列表信息
	def yunqiListSpider(self, response):
		'''
			解析列表信息：	
		'''
		books=response.xpath('//div[@class="book"]')
		for book in books:
			#1.小说的编号
			novelId=book.xpath("./div[@class='book_info']/h3/a/@id").extract_first()
			#2.小说的名字
			novelName=book.xpath("./div[@class='book_info']/h3/a/text()").extract_first()
			#获取小说信息
			bookInfo=book.xpath("./div[@class='book_info']/dl/dd[@class='w_auth']")
			if len(bookInfo)>=5:
				#3.小说的作者
				novelAuthor=bookInfo[0].xpath("./a/text()").extract_first()
				#4.小说的分类
				novelType=bookInfo[1].xpath("./a/text()").extract_first()
				#5.小说的状态
				novelStatus=bookInfo[2].xpath("./text()").extract_first()
				#6.小说的更新时间
				novelUpdateTime=bookInfo[3].xpath("./text()").extract_first()
				#7.小说的字数
				novelWords=bookInfo[4].xpath("./text()").extract_first()
				
			#8.详细信息的url
			novelDetailUrl=book.xpath("./div[@class='book_info']/h3/a/@href").extract_first()
			#9.小说的封面的url
			novelImageUrl=book.xpath("./a/img/@src").extract_first()
			#创建Item对象
			yunqiBookListItem=YunqiBookListItem(
				novelId=novelId,
				novelName=novelName,
				novelAuthor=novelAuthor,
				novelType=novelType,
				novelStatus=novelStatus,
				novelUpdateTime=novelUpdateTime,
				novelWords=novelWords,
				novelLink=novelDetailUrl,
				novelImageUrl=novelImageUrl)
			print '--------------------------------------------书的列表信息------------------------------'
			print yunqiBookListItem
			yield yunqiBookListItem
			request=scrapy.Request(url=novelDetailUrl,callback=self.yunqiDetailSpider)
			request.meta['novelId']=novelId
			yield request
			
	#解析详细信息
	def yunqiDetailSpider(self,response):
		#1.小说的编号
		novelId=response.meta['novelId']
		#2.小说的作品标签
		novelLable=response.xpath("//div[@class='tags']").extract_first()
		#获取存储小说信息的表格元素
		table=response.xpath("//div[@id='novelInfo']/table")
		#3.小说的总点击量
		novelAllClick=table.xpath("./tr[2]/td[1]/text()").extract_first()
		#4.小说的月点击量
		novelMonthClick=table.xpath("./tr[3]/td[1]/text()").extract_first()
		#5.小说的周点击量
		novelWeekClick=table.xpath("./tr[4]/td[1]/text()").extract_first()
		#6.小说的总人气
		novelAllPopular=table.xpath("./tr[2]/td[2]/text()").extract_first()
		#7.小说的月人气
		novelMonthPopular=table.xpath("./tr[3]/td[2]/text()").extract_first()
		#8.小说的周人气
		novelWeekPopular=table.xpath("./tr[4]/td[2]/text()").extract_first()
		#9.小说的总推荐
		novelAllComm=table.xpath("./tr[2]/td[3]/text()").extract_first()
		#10.小说的月推荐
		novelMonthComm=table.xpath("./tr[3]/td[3]/text()").extract_first()
		#11.小说的周推荐
		novelWeekComm=table.xpath("./tr[4]/td[3]/text()").extract_first()
		#12.总评论数
		novelCommentNum=table.xpath("./tr[5]/td[2]/text()").extract_first()
		yunqiBookDetailItem=YunqiBookDetailItem(
		novelId=novelId,
		novelLabel=novelLable,
		novelAllClick=novelAllClick,
		novelMonthClick=novelMonthClick,
		novelWeekClick=novelWeekClick,
		novelAllPopular=novelAllPopular,
		novelMonthPopular=novelMonthPopular,
		novelWeekPopular=novelWeekPopular,
		novelAllComm=novelAllComm,
		novelMonthComm=novelMonthComm,
		novelWeekComm=novelWeekComm,
		novelCommentNum=novelCommentNum
		)
		print '--------------------------------------------书的详细信息------------------------------'
		print yunqiBookDetailItem
		yield yunqiBookDetailItem
