#coding:utf-8
from scrapy.pipelines.images import ImagesPipeline
from scrapy.exceptions import DropItem
import scrapy

class myImagePipelines(ImagesPipeline):

	#重写get_media_requests(self,item,info)
	def get_media_requests(self,item,info):
		for image_url in item['image_urls']:
			yield scrapy.Request(url=image_url)
		

	#重写item_completed()
	def item_completed(self,result,item,info):
		image_path=[x['path'] for ok,x in result if ok]
		if not image_path:
			raise DropItem('item中没有图片')
		item['image_paths']=image_path
		return item
		
		
	
